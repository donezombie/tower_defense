import pygame

from game_object import GameObject, add, update, render
from enemy import Enemy
from bullet import PlayerBullet
from player import Player
from input_manager import InputManager

pygame.init()

clock = pygame.time.Clock()

SCREEN_SIZE = (600, 800)

canvas = pygame.display.set_mode(SCREEN_SIZE)
pygame.display.set_caption("Micro-war")

# 1
background_image = pygame.image.load("images/background/background.png")

input_manager = InputManager()

enemy = Enemy(300, 0)
enemy.image = pygame.image.load("images/enemy/bacteria/bacteria1.png")

player = Player(300, 700, input_manager) # __init__
player.image = pygame.image.load("images/player/MB-69/player1.png")

add(player)
add(enemy)

# right_pressed = False
# left_pressed = False
# down_pressed = False
# up_pressed = False
# x_pressed = False

loop = True

while loop:
    events = pygame.event.get()
    for event in events:
        if event.type == pygame.QUIT:
            loop = False
        else:
            input_manager.update(event)

    update()

    # 2
    canvas.blit(background_image, (0, 0))

    render(canvas)

    pygame.display.flip()
    clock.tick(60)
